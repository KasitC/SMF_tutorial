library(testthat)
library(SingleMoleculeFootprinting)

test_check("SingleMoleculeFootprinting")
